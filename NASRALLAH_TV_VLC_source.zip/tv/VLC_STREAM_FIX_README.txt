NASRALLAH TV - Stream playback source update

Changes:
- Adds the native LibVLC Android engine (libvlc-all 3.6.0) using VideoLAN's Maven repository.
- Uses LibVLC first for direct MPEG-TS (.ts) and HLS (.m3u8) streams.
- Falls back to AndroidX Media3 if LibVLC reports a playback error.
- Adds MIME inference for direct .ts and HLS URLs when Media3 is used.
- Normalizes URLs without http:// or https:// (such as an IP:port/path playlist URL) to http://.
- Keeps the existing TV layout and channel UI.

Important:
- This is an updated Android Studio source project, not a newly compiled APK.
- Build it in Android Studio with internet access so Gradle can download LibVLC.
- Playback still depends on the stream being live/authorized, reachable, and containing supported audio/video tracks. Some H.265 streams require hardware decoder support on the TV.
