package com.kurdtv.official

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.constraintlayout.widget.ConstraintLayout
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.imageLoader
import coil.request.ImageRequest
import com.kurdtv.official.models.Channel
import com.kurdtv.official.network.ChannelRepository
import com.kurdtv.official.network.StreamResolver
import com.kurdtv.official.ui.ChannelAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var vlcVideoLayout: VLCVideoLayout
    private lateinit var libVLC: LibVLC
    private lateinit var vlcPlayer: MediaPlayer
    private var usingVlc = false
    private var currentStreamUrl: String? = null
    private var vlcFallbackAttempted = false
    private lateinit var sidebarContainer: View
    private lateinit var channelList: RecyclerView
    private lateinit var categoryLayout: LinearLayout
    private lateinit var loadingOverlay: View
    private lateinit var errorPlaceholder: ImageView
    private lateinit var channelInfoOverlay: View
    private lateinit var overlayChannelNumber: TextView
    private lateinit var overlayChannelTitle: TextView
    
    private val channelRepository = ChannelRepository()
    private val streamResolver = StreamResolver()
    private lateinit var streamHijacker: com.kurdtv.official.network.StreamHijacker
    private lateinit var adapter: ChannelAdapter

    private var allChannels = listOf<Channel>()
    private var currentCategory = "هەمووی"
    private var currentChannel: Channel? = null

    private var resolveJob: kotlinx.coroutines.Job? = null
    private var refreshJob: kotlinx.coroutines.Job? = null
    private var digitBuffer = ""
    private val digitRunnable = Runnable { processDigitBuffer() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide() 
        setContentView(R.layout.activity_main)

        streamHijacker = com.kurdtv.official.network.StreamHijacker(this)

        playerView = findViewById(R.id.player_view)
        setupVlcPlayer()
        sidebarContainer = findViewById(R.id.sidebar_container)
        channelList = findViewById(R.id.channel_list)
        categoryLayout = findViewById(R.id.category_layout)
        loadingOverlay = findViewById(R.id.loading_overlay)
        errorPlaceholder = findViewById(R.id.error_placeholder)
        channelInfoOverlay = findViewById(R.id.channel_info_overlay)
        overlayChannelNumber = findViewById(R.id.overlay_channel_number)
        overlayChannelTitle = findViewById(R.id.overlay_channel_title)

        setupPlayer()
        setupChannelList()
        setupInteractions()
        hideSystemUI()

        loadChannels()
    }

    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    private fun setupPlayer() {
        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(15000, 50000, 2500, 5000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val trackSelectionFactory = androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection.Factory()
        val trackSelector = androidx.media3.exoplayer.trackselection.DefaultTrackSelector(this, trackSelectionFactory)

        player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .build()
        
        playerView.player = player
        
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == androidx.media3.common.Player.STATE_READY) {
                    loadingOverlay.visibility = View.GONE
                    errorPlaceholder.visibility = View.GONE
                    playerView.visibility = View.VISIBLE
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                Log.e("TV", "Media3 playback error: ${error.message}")
                val url = currentStreamUrl
                if (!usingVlc && url != null && isVlcSupportedStream(url) && !vlcFallbackAttempted) {
                    vlcFallbackAttempted = true
                    playWithVlc(url)
                } else {
                    loadingOverlay.visibility = View.GONE
                    showErrorPlaceholder()
                }
            }
        })
    }

    /** Real LibVLC engine, used for direct MPEG-TS and HLS streams. */
    private fun setupVlcPlayer() {
        try {
            val root = findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as ViewGroup
            vlcVideoLayout = VLCVideoLayout(this)
            val params = ConstraintLayout.LayoutParams(0, 0).apply {
                startToStart = ConstraintLayout.LayoutParams.PARENT_ID
                endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
                topToTop = ConstraintLayout.LayoutParams.PARENT_ID
                bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
            }
            // Keep the VLC surface above the Media3 surface, but below app overlays.
            root.addView(vlcVideoLayout, minOf(1, root.childCount), params)
            vlcVideoLayout.visibility = View.GONE
            val options = arrayListOf(
                "--network-caching=1800",
                "--live-caching=1800",
                "--file-caching=1000",
                "--no-video-title-show",
                "--audio-time-stretch",
                "--http-reconnect"
            )
            libVLC = LibVLC(this, options)
            vlcPlayer = MediaPlayer(libVLC)
            vlcPlayer.attachViews(vlcVideoLayout, null, false, false)
            vlcPlayer.setEventListener { event ->
                when (event.type) {
                    MediaPlayer.Event.Playing -> runOnUiThread {
                        usingVlc = true
                        loadingOverlay.visibility = View.GONE
                        errorPlaceholder.visibility = View.GONE
                        playerView.visibility = View.GONE
                        vlcVideoLayout.visibility = View.VISIBLE
                    }
                    MediaPlayer.Event.EncounteredError -> runOnUiThread {
                        val url = currentStreamUrl
                        Log.e("TV", "LibVLC stream error: $url")
                        if (url != null && !vlcFallbackAttempted) {
                            vlcFallbackAttempted = true
                            playWithMedia3(url)
                        } else {
                            loadingOverlay.visibility = View.GONE
                            showErrorPlaceholder()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("TV", "LibVLC initialization failed; Media3 remains available", e)
        }
    }

    private fun normalizeStreamUrl(rawUrl: String): String {
        val value = rawUrl.trim()
        if (value.startsWith("//")) return "https:$value"
        val hasScheme = value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))
        return if (hasScheme) value else "http://$value"
    }

    private fun isVlcSupportedStream(url: String): Boolean {
        val normalized = normalizeStreamUrl(url)
        val path = try { android.net.Uri.parse(normalized).path.orEmpty().lowercase() } catch (_: Exception) { normalized.lowercase() }
        return path.endsWith(".ts") || path.endsWith(".m3u8")
    }

    private fun showErrorPlaceholder() {
        try { if (::vlcPlayer.isInitialized) vlcPlayer.stop() } catch (_: Exception) { }
        usingVlc = false
        player.stop()
        playerView.visibility = View.GONE
        if (::vlcVideoLayout.isInitialized) vlcVideoLayout.visibility = View.GONE
        errorPlaceholder.visibility = View.VISIBLE
        // Load the provided error image
        val errorImageUrl = "https://i.postimg.cc/qvpQyK8q/Kurd-TV-Player.jpg" 
        val request = ImageRequest.Builder(this)
            .data(errorImageUrl)
            .target(errorPlaceholder)
            .build()
        imageLoader.enqueue(request)
        
        // Show sidebar so user can pick another channel
        sidebarContainer.visibility = View.VISIBLE
        sidebarContainer.bringToFront()
        channelList.requestFocus()
    }

    private fun setupChannelList() {
        adapter = ChannelAdapter { channel -> playChannel(channel) }
        channelList.layoutManager = LinearLayoutManager(this)
        channelList.adapter = adapter
    }

    private fun setupCategories(channelList: List<Channel>) {
        val dynamicCategories = mutableListOf("All")
        channelList.forEach { 
            val englishCat = when(it.category) {
                "هەمووی" -> "All"
                "منداڵان" -> "Kids"
                "وەرزشی" -> "Sports"
                "نیوس" -> "News"
                "دۆکۆمێنتەری" -> "Documentary"
                "بیانی" -> "Foreign"
                else -> it.category
            }
            if (!dynamicCategories.contains(englishCat)) {
                dynamicCategories.add(englishCat)
            }
        }

        categoryLayout.removeAllViews()
        for (cat in dynamicCategories) {
            val btn = Button(this).apply {
                text = cat
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                isFocusable = true
                textSize = 14f
                setPadding(20, 10, 20, 10)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = 10 }
            }

            btn.setOnClickListener { 
                currentCategory = when(cat) {
                    "All" -> "هەمووی"
                    "Kids" -> "منداڵان"
                    "Sports" -> "وەرزشی"
                    "News" -> "نیوس"
                    "Documentary" -> "دۆکۆمێنتەری"
                    "Foreign" -> "بیانی"
                    else -> cat
                }
                filterChannels(currentCategory) 
            }
            btn.setOnFocusChangeListener { view, hasFocus ->
                view.setBackgroundColor(if (hasFocus) 0xFF3498db.toInt() else Color.TRANSPARENT)
            }
            categoryLayout.addView(btn)
        }
    }

    private fun filterChannels(category: String) {
        currentCategory = category
        val filtered = if (category == "هەمووی" || category == "گشتی") allChannels else allChannels.filter { it.category == category }
        adapter.setChannels(filtered)
    }

    private fun setupInteractions() {
        playerView.setOnClickListener { toggleSidebar() }
        sidebarContainer.visibility = View.GONE
    }

    private fun toggleSidebar() {
        if (sidebarContainer.visibility == View.VISIBLE) {
            sidebarContainer.visibility = View.GONE
        } else {
            sidebarContainer.visibility = View.VISIBLE
            sidebarContainer.bringToFront()
            
            // Focus current channel instead of first one
            currentChannel?.let { ch ->
                val index = allChannels.indexOf(ch)
                if (index != -1) {
                    channelList.scrollToPosition(index)
                    channelList.postDelayed({
                        channelList.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus()
                    }, 100)
                }
            } ?: channelList.requestFocus()
        }
    }

    private fun loadChannels() {
        lifecycleScope.launch {
            loadingOverlay.visibility = View.VISIBLE
            try {
                allChannels = channelRepository.getChannels()
                setupCategories(allChannels)
                filterChannels(currentCategory)
                if (allChannels.isNotEmpty()) playChannel(allChannels[0])
            } catch (e: Exception) {
                Log.e("TV", "Load channels failed", e)
            }
            loadingOverlay.visibility = View.GONE
        }
    }

    private fun playChannel(channel: Channel) {
        currentChannel = channel
        resolveJob?.cancel()
        refreshJob?.cancel()
        sidebarContainer.visibility = View.GONE
        showChannelInfo(channel)
        
        errorPlaceholder.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        loadingOverlay.visibility = View.VISIBLE
        vlcFallbackAttempted = false
        currentStreamUrl = null

        resolveJob = lifecycleScope.launch {
            player.stop()
            player.clearMediaItems()
            try { if (::vlcPlayer.isInitialized) vlcPlayer.stop() } catch (_: Exception) { }
            usingVlc = false
            if (::vlcVideoLayout.isInitialized) vlcVideoLayout.visibility = View.GONE
            playerView.visibility = View.VISIBLE
            
            // Initial Resolution
            val sourceUrl = normalizeStreamUrl(channel.url)
            val streamUrl = streamResolver.resolve(sourceUrl) ?: streamHijacker.hijack(sourceUrl)
            
            if (streamUrl != null) {
                playStream(streamUrl)
                startAutoRefresh(channel)
            } else {
                loadingOverlay.visibility = View.GONE
                showErrorPlaceholder()
            }
        }
    }

    private fun playStream(streamUrl: String) {
        currentStreamUrl = streamUrl
        vlcFallbackAttempted = false
        if (isVlcSupportedStream(streamUrl) && ::vlcPlayer.isInitialized) {
            playWithVlc(streamUrl)
        } else {
            playWithMedia3(streamUrl)
        }
    }

    private fun playWithVlc(streamUrl: String) {
        if (!::vlcPlayer.isInitialized) {
            playWithMedia3(streamUrl)
            return
        }
        try {
            usingVlc = true
            player.pause()
            playerView.visibility = View.GONE
            vlcVideoLayout.visibility = View.VISIBLE
            val media = Media(libVLC, android.net.Uri.parse(streamUrl)).apply {
                setHWDecoderEnabled(true, false)
                addOption(":network-caching=1800")
                addOption(":live-caching=1800")
                addOption(":http-user-agent=Mozilla/5.0 (Linux; Android TV) AppleWebKit/537.36 Chrome/120 Safari/537.36")
                addOption(":http-reconnect")
            }
            vlcPlayer.stop()
            vlcPlayer.media = media
            media.release()
            vlcPlayer.volume = 100
            vlcPlayer.play()
        } catch (e: Exception) {
            Log.e("TV", "Unable to start LibVLC; falling back to Media3", e)
            usingVlc = false
            playWithMedia3(streamUrl)
        }
    }

    private fun playWithMedia3(streamUrl: String) {
        try {
            usingVlc = false
            if (::vlcVideoLayout.isInitialized) vlcVideoLayout.visibility = View.GONE
            playerView.visibility = View.VISIBLE
            val mimeType = when {
                streamUrl.contains(".mpd", ignoreCase = true) -> androidx.media3.common.MimeTypes.APPLICATION_MPD
                streamUrl.contains(".m3u8", ignoreCase = true) -> androidx.media3.common.MimeTypes.APPLICATION_M3U8
                streamUrl.substringBefore('?').endsWith(".ts", ignoreCase = true) -> androidx.media3.common.MimeTypes.VIDEO_MP2T
                else -> null
            }
            val builder = MediaItem.Builder().setUri(streamUrl)
            if (mimeType != null) builder.setMimeType(mimeType)
            player.setMediaItem(builder.build())
            player.prepare()
            player.playWhenReady = true
            player.volume = 1f
        } catch (e: Exception) {
            Log.e("TV", "Media3 failed to start stream", e)
            loadingOverlay.visibility = View.GONE
            showErrorPlaceholder()
        }
    }

    private fun startAutoRefresh(channel: Channel) {
        refreshJob?.cancel()
        refreshJob = lifecycleScope.launch {
            while (true) {
                kotlinx.coroutines.delay(10000) // 10 seconds refresh as requested
                Log.d("TV", "Auto-refreshing stream for: ${channel.title}")
                
                // Fetch fresh URL in background
                val sourceUrl = normalizeStreamUrl(channel.url)
                val freshUrl = streamResolver.resolve(sourceUrl) ?: streamHijacker.hijack(sourceUrl)
                
                if (freshUrl != null) {
                    val currentUri = currentStreamUrl.orEmpty()
                    if (freshUrl != currentUri) {
                        Log.d("TV", "Token updated! Syncing player...")
                        withContext(Dispatchers.Main) { playStream(freshUrl) }
                    }
                }
            }
        }
    }

    private fun showChannelInfo(channel: Channel) {
        val index = allChannels.indexOf(channel)
        overlayChannelNumber.text = "#${index + 1}"
        overlayChannelTitle.text = channel.title
        channelInfoOverlay.visibility = View.VISIBLE
        channelInfoOverlay.removeCallbacks(hideOverlayRunnable)
        channelInfoOverlay.postDelayed(hideOverlayRunnable, 3000)
    }

    private val hideOverlayRunnable = Runnable { channelInfoOverlay.visibility = View.GONE }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Joker Remote Support: Capture Numbers 0-9
        if (keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) {
            handleNumberKey(keyCode - KeyEvent.KEYCODE_0)
            return true
        }

        // Broad Remote Support (Generic codes)
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == 23) {
            toggleSidebar()
            return true
        }
        
        if ((keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == 21) && sidebarContainer.visibility != View.VISIBLE) {
            toggleSidebar()
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == 4) {
            if (sidebarContainer.visibility == View.VISIBLE) {
                sidebarContainer.visibility = View.GONE
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun handleNumberKey(digit: Int) {
        digitBuffer += digit.toString()
        showChannelInfoText("Channel: $digitBuffer")
        sidebarContainer.removeCallbacks(digitRunnable)
        sidebarContainer.postDelayed(digitRunnable, 2000) // Execute after 2s of no input
    }

    private fun processDigitBuffer() {
        val channelNum = digitBuffer.toIntOrNull() ?: return
        digitBuffer = ""
        
        if (channelNum in 1..allChannels.size) {
            playChannel(allChannels[channelNum - 1])
        } else {
            showChannelInfoText("Not Found")
        }
    }

    private fun showChannelInfoText(msg: String) {
        overlayChannelTitle.text = msg
        overlayChannelNumber.text = ""
        channelInfoOverlay.visibility = View.VISIBLE
        channelInfoOverlay.removeCallbacks(hideOverlayRunnable)
        channelInfoOverlay.postDelayed(hideOverlayRunnable, 3000)
    }

    private fun hideSystemUI() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (::vlcPlayer.isInitialized) {
                vlcPlayer.setEventListener(null)
                vlcPlayer.stop()
                vlcPlayer.detachViews()
                vlcPlayer.release()
            }
            if (::libVLC.isInitialized) libVLC.release()
        } catch (e: Exception) {
            Log.w("TV", "Error releasing LibVLC", e)
        }
        player.release()
    }
}
