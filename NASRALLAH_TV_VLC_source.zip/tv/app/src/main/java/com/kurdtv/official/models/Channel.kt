package com.kurdtv.official.models

data class Channel(
    val title: String,
    val url: String,
    val thumbnailUrl: String? = null,
    val category: String = "گشتی",
    val order: Int = 0
)
