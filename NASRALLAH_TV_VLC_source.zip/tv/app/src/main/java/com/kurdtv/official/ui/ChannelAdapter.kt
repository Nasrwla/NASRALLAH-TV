package com.kurdtv.official.ui

import android.view.LayoutInflater
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.kurdtv.official.R
import com.kurdtv.official.models.Channel

class ChannelAdapter(
    private val onChannelClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ViewHolder>() {

    private var channels = listOf<Channel>()

    fun setChannels(newChannels: List<Channel>) {
        channels = newChannels
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val channel = channels[position]
        holder.number.text = "#${position + 1}"
        holder.title.text = channel.title
        
        // Use a better placeholder and fix image loading issues
        holder.thumb.load(channel.thumbnailUrl) {
            crossfade(true)
            listener(
                onError = { _, result ->
                    Log.e("ChannelAdapter", "Error loading thumb: ${channel.thumbnailUrl}", result.throwable)
                }
            )
        }
        
        holder.itemView.setOnClickListener { onChannelClick(channel) }
        
        // Handle focus for TV
        holder.itemView.setOnFocusChangeListener { view, hasFocus ->
            if (hasFocus) {
                view.setBackgroundColor(0xFF444444.toInt())
                view.scaleX = 1.05f
                view.scaleY = 1.05f
            } else {
                view.setBackgroundColor(0x00000000)
                view.scaleX = 1.0f
                view.scaleY = 1.0f
            }
        }
    }

    override fun getItemCount() = channels.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val number: TextView = view.findViewById(R.id.channel_number)
        val thumb: ImageView = view.findViewById(R.id.channel_thumb)
        val title: TextView = view.findViewById(R.id.channel_title)
    }
}
