package com.kurdtv.official.activity

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.kurdtv.official.R
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.*
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter

class LockActivity : AppCompatActivity() {

    private lateinit var deviceId: String
    private var dbRef: DatabaseReference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Initialize Firebase with provided options
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApiKey("AIzaSyDF61ImOXNwNElz15gX1wRfv6rLFehDfhg")
                    .setApplicationId("1:195143331310:android:ba75b1f7be00c6d980b2ff")
                    .setDatabaseUrl("https://kurd-96a88-default-rtdb.firebaseio.com")
                    .setProjectId("kurd-96a88")
                    .build()
                FirebaseApp.initializeApp(this, options)
            }
            dbRef = FirebaseDatabase.getInstance().getReference("devices")
        } catch (e: Exception) { e.printStackTrace() }

        // 2. Check local cache for activation
        val prefs = getSharedPreferences("activation_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("is_active", false)) {
            val expiry = prefs.getLong("expiry_date", 0L)
            if (System.currentTimeMillis() < expiry) {
                goToMain()
                return
            }
        }

        setContentView(R.layout.activity_lock)
        hideSystemUi()

        val txtDeviceId = findViewById<TextView>(R.id.txtDeviceId)
        val imgQrCode = findViewById<ImageView>(R.id.imgQrCode)

        // 3. Get Unique Device ID (Last 8 chars as requested)
        deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID).takeLast(8).uppercase()
        txtDeviceId.text = "DEVICE ID: $deviceId"

        // 4. Create QR Link (Correct link as provided by you)
        val activationUrl = "https://long-wind-30fd.hawlerynasrwla5.workers.dev/?id=$deviceId"
        
        try {
            val bitMatrix = MultiFormatWriter().encode(activationUrl, BarcodeFormat.QR_CODE, 512, 512)
            val width = bitMatrix.width
            val height = bitMatrix.height
            val pixels = IntArray(width * height)
            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (bitMatrix.get(x, y)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
                }
            }
            val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            imgQrCode.setImageBitmap(bitmap)
        } catch (e: Exception) { e.printStackTrace() }

        listenForActivation()
    }

    private fun listenForActivation() {
        dbRef?.child(deviceId)?.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val status = snapshot.child("status").getValue(String::class.java)
                    val expiryDate = snapshot.child("expiry_date").getValue(Long::class.java) ?: 0L

                    if (status == "active" && System.currentTimeMillis() < expiryDate) {
                        getSharedPreferences("activation_prefs", Context.MODE_PRIVATE).edit().apply {
                            putBoolean("is_active", true)
                            putLong("expiry_date", expiryDate)
                            apply()
                        }
                        Toast.makeText(this@LockActivity, "بە سەرکەوتوویی چالاک کرا!", Toast.LENGTH_SHORT).show()
                        goToMain()
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun goToMain() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }

    private fun hideSystemUi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }
}
