package com.kurdtv.official.network

import okhttp3.OkHttpClient
import okhttp3.Request
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class StreamResolver {
    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val userAgent = "Mozilla/5.0 (Linux; Android 10; BRAVIA 4K VH2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36"

    suspend fun resolve(channelUrl: String): String? = withContext(Dispatchers.IO) {
        // --- DEEP-CORE PERMANENT SCRAPER (FORCE PLAY) ---
        try {
            Log.d("StreamResolver", "Force-Resolving Deep Core: $channelUrl")
            
            // Return known direct media URLs untouched. In particular, .ts is
            // a valid MPEG-TS stream and must not be treated as a web page to scrape.
            val path = try { java.net.URI(channelUrl).path.orEmpty().lowercase() }
                       catch (_: Exception) { channelUrl.substringBefore('?').lowercase() }
            if (path.endsWith(".m3u8") || path.endsWith(".mpd") ||
                path.endsWith(".ts") || path.endsWith(".mp4") ||
                path.endsWith(".m4v") || path.endsWith(".mp3") ||
                path.endsWith(".aac") || path.endsWith(".mp2t")) {
                return@withContext channelUrl
            }

            val slug = channelUrl.trimEnd('/').split("/").last()
            
            // Parallel Deep Search in the 'Hearts' of the site
            val mainDeferred = async { fetchHtml(channelUrl) }
            val liveDeferred = async { fetchHtml("https://karwan.tv/live/$slug/") }
            val embedDeferred = async { fetchHtml("https://karwan.tv/embed/$slug/") }

            val pages = listOfNotNull(mainDeferred.await(), liveDeferred.await(), embedDeferred.await())

            for (html in pages) {
                findTokenizedM3u8(html)?.let { return@withContext it }
                findFlussonicM3u8(html)?.let { return@withContext it }
                
                // Deep-Core JS Search (Look for hidden static streams)
                val corePatterns = listOf(
                    "source\\s*:\\s*['\"]([^'\"]+(?:m3u8|mpd)[^'\"]*)['\"]",
                    "file\\s*:\\s*['\"]([^'\"]+(?:m3u8|mpd)[^'\"]*)['\"]",
                    "['\"](https://[^'\"]+/index\\.m3u8[^'\"]*)['\"]"
                )
                for (p in corePatterns) {
                    val m = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(html)
                    if (m.find()) return@withContext m.group(1)
                }
            }

            return@withContext null
        } catch (e: Exception) {
            Log.e("StreamResolver", "Core Resolve error", e)
            null
        }
    }

    private fun fetchHtml(url: String): String? {
        return try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()
            client.newCall(request).execute().use { it.body?.string() }
        } catch (e: Exception) { null }
    }

    private fun findTokenizedM3u8(html: String): String? {
        val patterns = listOf(
            "\"(https://[^\"]+index\\.mpd\\?token=[^\"]+)\"", // NEW DASH (.mpd) pattern
            "\"(https://[^\"]+mono\\.m3u8\\?token=[^\"]+)\"",
            "'(https://[^']+mono\\.m3u8\\?token=[^']+)'",
            "\"(https://[^\"]+index\\.m3u8\\?token=[^\"]+)\"",
            "\"(https://[^\"]+/tracks-[^\"]+\\.m3u8\\?token=[^\"]+)\"", // New pattern
            "\"(https://[^\"]+/playlist\\.m3u8\\?token=[^\"]+)\"", // Another variant
            "url\\s*:\\s*['\"]([^'\"]+(?:m3u8|mpd)[^'\"]*)['\"]" // Broad JS match for both
        )
        for (p in patterns) {
            val matcher = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(html)
            if (matcher.find()) return matcher.group(1)
        }
        return null
    }

    private fun findFlussonicM3u8(html: String): String? {
        val patterns = listOf(
            "src=\"(https://[^\"]+embed\\.html\\?[^\"]+)\"",
            "src=\"(https://[^\"]+/live/[^\"]+/embed\\.html[^\"]*)\""
        )
        for (p in patterns) {
            val matcher = Pattern.compile(p).matcher(html)
            if (matcher.find()) {
                val url = matcher.group(1)
                return if (html.contains(".mpd")) {
                    url?.replace("embed.html", "index.mpd")
                } else {
                    url?.replace("embed.html", "index.m3u8")
                }
            }
        }
        return null
    }
}
