package com.kurdtv.official.network

import com.kurdtv.official.models.Channel
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.Log
import org.json.JSONObject

class ChannelRepository {
    private val client = OkHttpClient()

    // --- ئەمە ئەو شوێنەیە کە لینکی فایربەیسەکەت تێدا دادەنێیت ---
    private val firebaseDatabaseUrl = "https://kurd-96a88-default-rtdb.firebaseio.com/channels.json"

    suspend fun getChannels(): List<Channel> = withContext(Dispatchers.IO) {
        val allChannels = mutableListOf<Channel>()
        
        try {
            if (firebaseDatabaseUrl.contains("http")) {
                val request = Request.Builder().url(firebaseDatabaseUrl).build()
                val response = client.newCall(request).execute().use { it.body?.string() }
                
                if (response != null && response != "null") {
                    val json = JSONObject(response)
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val obj = json.getJSONObject(key)
                        
                        val title = obj.optString("title", "بێ ناو")
                        val url = obj.optString("url", "")
                        val thumb = obj.optString("thumbnailUrl", "")
                        val category = obj.optString("category", "هەمووی")
                        val order = obj.optInt("order", 0)
                        
                        if (url.isNotEmpty()) {
                            allChannels.add(Channel(title, url, thumb, category, order))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("ChannelRepository", "Firebase Fetch Error", e)
        }
        
        return@withContext allChannels.sortedBy { it.order }
    }
}
