package com.kurdtv.official.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.kurdtv.official.MainActivity
import com.kurdtv.official.R

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_home)
        hideSystemUI()

        val btnLiveTv = findViewById<LinearLayout>(R.id.btn_live_tv)
        val btnYoutube = findViewById<LinearLayout>(R.id.btn_youtube)
        val btnMovies = findViewById<LinearLayout>(R.id.btn_movies)

        btnLiveTv.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        btnYoutube.setOnClickListener {
            startActivity(Intent(this, YouTubeActivity::class.java))
        }

        btnMovies.setOnClickListener {
            Toast.makeText(this, "بەم زووانە... (Coming Soon)", Toast.LENGTH_SHORT).show()
        }

        // Set initial focus
        btnLiveTv.requestFocus()
    }

    private fun hideSystemUI() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }
    
    override fun onResume() {
        super.onResume()
        hideSystemUI()
    }
}
