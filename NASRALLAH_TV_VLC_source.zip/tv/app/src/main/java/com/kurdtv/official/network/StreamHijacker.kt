package com.kurdtv.official.network

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

class StreamHijacker(private val context: Context) {

    private val userAgent = "Mozilla/5.0 (Linux; Android 10; BRAVIA 4K VH2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36"

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun hijack(url: String): String? {
        Log.d("StreamHijacker", "Starting Hijack for: $url")
        val deferred = CompletableDeferred<String?>()
        val handler = Handler(Looper.getMainLooper())

        handler.post {
            val webView = WebView(context)
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            webView.settings.userAgentString = userAgent
            
            // The "Magic": Intercept all outgoing network requests made by the website's JS
            webView.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val requestUrl = request?.url?.toString() ?: ""
                    
                    // --- ENHANCED DETECTION PATTERNS ---
                    val isStream = requestUrl.contains(".m3u8", ignoreCase = true) || 
                                 requestUrl.contains(".mpd", ignoreCase = true) ||
                                 requestUrl.contains("/playlist", ignoreCase = true) ||
                                 requestUrl.contains("/manifest", ignoreCase = true)

                    if (isStream) {
                        // We take ANY stream link that has a token or looks like a direct source
                        if (requestUrl.contains("token=") || requestUrl.contains("/tracks-") || requestUrl.contains(":333") || requestUrl.contains(":444")) {
                            Log.d("StreamHijacker", "HIJACKED SUCCESS: $requestUrl")
                            if (!deferred.isCompleted) {
                                deferred.complete(requestUrl)
                                handler.post { 
                                    webView.stopLoading()
                                    webView.destroy() 
                                }
                            }
                        }
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    // Inject early to catch events
                    view?.evaluateJavascript("""
                        window.confirm = function() { return true; };
                        window.alert = function() { return true; };
                    """, null)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    // Ultra-Aggressive Interaction Script
                    view?.evaluateJavascript("""
                        (function() {
                            console.log("Triggering auto-play events...");
                            // 1. Click every play button, icon, or large div
                            const selectors = ['button', '.play-btn', '#play', '.vjs-big-play-button', '.play-icon', 'video'];
                            selectors.forEach(s => {
                                document.querySelectorAll(s).forEach(el => {
                                    try { el.click(); } catch(e){}
                                });
                            });
                            // 2. Trigger touch events
                            const evt = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
                            document.body.dispatchEvent(evt);
                        })();
                    """, null)
                }
            }

            webView.loadUrl(url)
        }

        // Wait up to 15 seconds for the JS to generate the link
        return withTimeoutOrNull(15000) {
            val result = deferred.await()
            result
        }
    }
}
