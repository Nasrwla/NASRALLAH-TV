plugins {
    alias(libs.plugins.android.application)
    // alias(libs.plugins.google.services) // Disabled until google-services.json is added
}

android {
    namespace = "com.kurdtv.official"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.kurdtv.official"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)
    implementation(libs.media3.hls)
    implementation(libs.media3.dash)
    // Native VLC engine for direct MPEG-TS and HLS streams
    implementation("org.videolan.android:libvlc-all:3.6.0")
    implementation(libs.okhttp)
    implementation(libs.coroutines.android)
    implementation(libs.androidx.recyclerview)
    implementation(libs.jsoup)
    implementation(libs.coil)
    implementation(libs.androidx.lifecycle.runtime.ktx)

    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:33.9.0"))
    implementation("com.google.firebase:firebase-database-ktx")

    // QR & ZXing
    implementation("com.google.zxing:core:3.5.3")
    // implementation("com.journeyapps:barcode-scanner-android-library:4.3.0")

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}